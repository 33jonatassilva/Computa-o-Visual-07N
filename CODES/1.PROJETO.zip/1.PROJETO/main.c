// Copyright (c) 2025 Andre Kishimoto - https://kishimoto.com.br/ 
// SPDX-License-Identifier: Apache-2.0

//------------------------------------------------------------------------------
// Exemplo: 04-invert_image
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Includes
//------------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>
#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>
#include <SDL3_image/SDL_image.h>
#include <SDL3_ttf/SDL_ttf.h>

//------------------------------------------------------------------------------
// Custom types, structs, constants, etc.
//------------------------------------------------------------------------------
static const char *WINDOW_TITLE = "Invert image";
static const char *FONT_FILENAME = "arial.ttf";
static const int FONT_SIZE = 18;

enum constants
{
    DEFAULT_WINDOW_WIDTH = 640,
    DEFAULT_WINDOW_HEIGHT = 480,

    DEFAULT_H_WINDOW_WIDTH = 540,
    DEFAULT_H_WINDOW_HEIGHT = 580,
};

typedef struct MyWindow MyWindow;
struct MyWindow
{
    SDL_Window *window;
    SDL_Renderer *renderer;
};

typedef struct MyImage MyImage;
struct MyImage
{
    SDL_Surface *surface;
    SDL_Texture *texture;
    SDL_FRect rect;
};

//------------------------------------------------------------------------------
// Globals
//------------------------------------------------------------------------------
static MyWindow g_window = { .window = NULL, .renderer = NULL };
static MyWindow h_window = { .window = NULL, .renderer = NULL };
static MyImage g_image = {
    .surface = NULL,
    .texture = NULL,
    .rect = { .x = 0.0f, .y = 0.0f, .w = 0.0f, .h = 0.0f }
};

int histogram[256] = { 0 };
static TTF_Font *g_font = NULL;

//------------------------------------------------------------------------------
// Function declarations (prototypes)
//------------------------------------------------------------------------------
static void render_text(SDL_Renderer *renderer, const char *text, int x, int y, SDL_Color color);
static bool MyWindow_initialize(MyWindow *window, const char *title, int width, int height, SDL_WindowFlags window_flags);
static void MyWindow_destroy(MyWindow *window);
static void MyImage_destroy(MyImage *image);
static void load_rgba32(const char *filename, SDL_Renderer *renderer, MyImage *output_image);
static void invert_image(SDL_Renderer *renderer, MyImage *image);

float calculate_intensity(Uint8 r, Uint8 g, Uint8 b);
float calculate_average_intensity(void);
float calculate_standard_deviation(void);
void calculate_histogram(void);

/* classify_* agora retornam strings para serem exibidas na janela do histograma */
const char *classify_intensity_string(int intensity);
const char *classify_deviation_string(float deviation);

/* render histogram retorna o max_value e preenche str_max_bar */
int render_histogram(char str_max_bar[16]);

//------------------------------------------------------------------------------
// Implementação de render_text
//------------------------------------------------------------------------------
static void render_text(SDL_Renderer *renderer, const char *text, int x, int y, SDL_Color color)
{
    if (!g_font)
    {
        SDL_Log("Erro: Fonte não carregada (g_font é NULL).");
        return;
    }

    // SDL3_ttf: TTF_RenderText_Solid(font, text, wrapLength, color)
    SDL_Surface *text_surface = TTF_RenderText_Solid(g_font, text, 0, color);
    if (!text_surface)
    {
        SDL_Log("Erro ao criar a superfície de texto: %s", SDL_GetError());
        return;
    }

    SDL_Texture *text_texture = SDL_CreateTextureFromSurface(renderer, text_surface);
    if (!text_texture)
    {
        SDL_Log("Erro ao criar a textura de texto: %s", SDL_GetError());
        SDL_DestroySurface(text_surface);
        return;
    }

    SDL_FRect dest_rect = {
        .x = (float)x,
        .y = (float)y,
        .w = (float)text_surface->w,
        .h = (float)text_surface->h
    };

    SDL_RenderTexture(renderer, text_texture, NULL, &dest_rect);

    SDL_DestroyTexture(text_texture);
    SDL_DestroySurface(text_surface);
}


//------------------------------------------------------------------------------
// Window / Image helpers
//------------------------------------------------------------------------------
static bool MyWindow_initialize(MyWindow *window, const char *title, int width, int height, SDL_WindowFlags window_flags)
{
    SDL_Log("\tMyWindow_initialize(%s, %d, %d)", title, width, height);
    return SDL_CreateWindowAndRenderer(title, width, height, window_flags, &window->window, &window->renderer);
}

static void MyWindow_destroy(MyWindow *window)
{
    SDL_Log(">>> MyWindow_destroy()");
    if (!window) return;

    if (window->renderer)
    {
        SDL_Log("\tDestruindo MyWindow->renderer...");
        SDL_DestroyRenderer(window->renderer);
        window->renderer = NULL;
    }

    if (window->window)
    {
        SDL_Log("\tDestruindo MyWindow->window...");
        SDL_DestroyWindow(window->window);
        window->window = NULL;
    }

    SDL_Log("<<< MyWindow_destroy()");
}

static void MyImage_destroy(MyImage *image)
{
    SDL_Log(">>> MyImage_destroy()");

    if (!image)
    {
        SDL_Log("\t*** Erro: Imagem inválida (image == NULL).");
        SDL_Log("<<< MyImage_destroy()");
        return;
    }

    if (image->texture)
    {
        SDL_Log("\tDestruindo MyImage->texture...");
        SDL_DestroyTexture(image->texture);
        image->texture = NULL;
    }

    if (image->surface)
    {
        SDL_Log("\tDestruindo MyImage->surface...");
        SDL_DestroySurface(image->surface);
        image->surface = NULL;
    }

    image->rect.x = image->rect.y = image->rect.w = image->rect.h = 0.0f;

    SDL_Log("<<< MyImage_destroy()");
}

//------------------------------------------------------------------------------
// load_rgba32
//------------------------------------------------------------------------------
static void load_rgba32(const char *filename, SDL_Renderer *renderer, MyImage *output_image)
{
    SDL_Log(">>> load_rgba32(\"%s\")", filename);

    if (!filename || !renderer || !output_image)
    {
        SDL_Log("\t*** Erro: parametros invalidos em load_rgba32");
        SDL_Log("<<< load_rgba32(\"%s\")", filename);
        return;
    }

    MyImage_destroy(output_image);

    SDL_Surface *surface = IMG_Load(filename);
    if (!surface)
    {
        SDL_Log("\t*** Erro ao carregar a imagem: %s", SDL_GetError());
        SDL_Log("<<< load_rgba32(\"%s\")", filename);
        return;
    }

    output_image->surface = SDL_ConvertSurface(surface, SDL_PIXELFORMAT_RGBA32);
    SDL_DestroySurface(surface);
    if (!output_image->surface)
    {
        SDL_Log("\t*** Erro ao converter superficie para RGBA32: %s", SDL_GetError());
        SDL_Log("<<< load_rgba32(\"%s\")", filename);
        return;
    }

    output_image->texture = SDL_CreateTextureFromSurface(renderer, output_image->surface);
    if (!output_image->texture)
    {
        SDL_Log("\t*** Erro ao criar textura: %s", SDL_GetError());
        SDL_Log("<<< load_rgba32(\"%s\")", filename);
        return;
    }

    SDL_GetTextureSize(output_image->texture, &output_image->rect.w, &output_image->rect.h);

    SDL_Log("<<< load_rgba32(\"%s\")", filename);
}

//------------------------------------------------------------------------------
// invert_image
//------------------------------------------------------------------------------
static void invert_image(SDL_Renderer *renderer, MyImage *image)
{
    SDL_Log(">>> invert_image()");

    if (!renderer || !image || !image->surface)
    {
        SDL_Log("\t*** Erro: parametros invalidos em invert_image");
        SDL_Log("<<< invert_image()");
        return;
    }

    SDL_LockSurface(image->surface);

    const SDL_PixelFormatDetails *format = SDL_GetPixelFormatDetails(image->surface->format);
    const size_t pixelCount = image->surface->w * image->surface->h;

    Uint32 *pixels = (Uint32 *)image->surface->pixels;
    Uint8 r = 0, g = 0, b = 0, a = 0;
    bool escaladecinza = true;

    for (size_t i = 0; i < pixelCount; ++i)
    {
        SDL_GetRGBA(pixels[i], format, NULL, &r, &g, &b, &a);
        if (!(r == g && g == b))
            escaladecinza = false;
    }

    if (!escaladecinza)
    {
        for (size_t i = 0; i < pixelCount; ++i)
        {
            SDL_GetRGBA(pixels[i], format, NULL, &r, &g, &b, &a);
            float y = 0.2125f * r + 0.7154f * g + 0.0721f * b;
            Uint8 yy = (Uint8)roundf(y);
            r = g = b = yy;
            pixels[i] = SDL_MapRGBA(format, NULL, r, g, b, a);
        }
    }

    SDL_UnlockSurface(image->surface);

    if (image->texture)
    {
        SDL_DestroyTexture(image->texture);
    }
    image->texture = SDL_CreateTextureFromSurface(renderer, image->surface);

    SDL_Log("<<< invert_image()");
}

//------------------------------------------------------------------------------
// initialize / shutdown
//------------------------------------------------------------------------------
static SDL_AppResult initialize(void)
{
    SDL_Log(">>> initialize()");

    SDL_Log("\tIniciando SDL...");
    if (!SDL_Init(SDL_INIT_VIDEO))
    {
        SDL_Log("\t*** Erro ao iniciar a SDL: %s", SDL_GetError());
        SDL_Log("<<< initialize()");
        return SDL_APP_FAILURE;
    }

    SDL_Log("\tIniciando SDL_ttf...");
    if (TTF_Init() != 1)
    {
        SDL_Log("\t*** Erro ao iniciar a SDL_ttf: %s", SDL_GetError());
        return SDL_APP_FAILURE;
    }

    SDL_Log("\tCriando janelas e renderizadores...");
    if (!MyWindow_initialize(&g_window, "IMAGEM", DEFAULT_WINDOW_WIDTH, DEFAULT_WINDOW_HEIGHT, 0) ||
        !MyWindow_initialize(&h_window, "HISTOGRAMA", DEFAULT_H_WINDOW_WIDTH, DEFAULT_H_WINDOW_HEIGHT, 0))
    {
        SDL_Log("\tErro ao criar a janela e/ou renderizador: %s", SDL_GetError());
        SDL_Log("<<< initialize()");
        return SDL_APP_FAILURE;
    }

    SDL_Log("<<< initialize()");
    return SDL_APP_CONTINUE;
}

static void shutdown(void)
{
    SDL_Log(">>> shutdown()");

    if (g_font)
    {
        TTF_CloseFont(g_font);
        g_font = NULL;
    }

    MyImage_destroy(&g_image);
    MyWindow_destroy(&g_window);
    MyWindow_destroy(&h_window);

    TTF_Quit();
    SDL_Quit();

    SDL_Log("<<< shutdown()");
}

//------------------------------------------------------------------------------
// Histogram rendering
//------------------------------------------------------------------------------
int render_histogram(char str_max_bar[16])
{
    int max_value = 1;
    for (int i = 0; i < 256; i++)
    {
        if (histogram[i] > max_value)
            max_value = histogram[i];
    }

    snprintf(str_max_bar, 16, "%d", max_value);

    float bar_width = (float)(DEFAULT_H_WINDOW_WIDTH - 80) / 256.0f;
    int graph_height = DEFAULT_H_WINDOW_HEIGHT - 240;
    int graph_y_start = 60;

    for (int i = 0; i < 256; i++)
    {
        float bar_height = ((float)histogram[i] / (float)max_value) * (graph_height - 40);
        SDL_SetRenderDrawColor(h_window.renderer, 200, 200, 220, 255);

        SDL_FRect bar = {
            .x = 40.0f + i * bar_width,
            .y = (float)graph_y_start + (float)graph_height - bar_height,
            .w = bar_width,
            .h = bar_height
        };
        SDL_RenderFillRect(h_window.renderer, &bar);
    }

    return max_value;
}

//------------------------------------------------------------------------------
// Render principal (imagem + histograma)
//------------------------------------------------------------------------------
static void render(void)
{
    // Janela da imagem
    SDL_SetRenderDrawColor(g_window.renderer, 128, 128, 128, 255);
    SDL_RenderClear(g_window.renderer);
    if (g_image.texture)
        SDL_RenderTexture(g_window.renderer, g_image.texture, &g_image.rect, &g_image.rect);
    SDL_RenderPresent(g_window.renderer);

    // Janela do histograma
    SDL_SetRenderDrawColor(h_window.renderer, 40, 40, 60, 255);
    SDL_RenderClear(h_window.renderer);

    char str_max_bar[16];
    int max_bar = render_histogram(str_max_bar);

    SDL_Color white = {255, 255, 255, 255};
    SDL_Color light_gray = {200, 200, 200, 255};

    // Título e eixos
    render_text(h_window.renderer, "Histograma de Intensidade", 150, 15, white);

    render_text(h_window.renderer, "Frequencia", 10, 35, light_gray);
    render_text(h_window.renderer, str_max_bar, 20, 55, light_gray);

    render_text(h_window.renderer, "Niveis de Cinza", 210 , DEFAULT_H_WINDOW_HEIGHT - 170, light_gray);
    render_text(h_window.renderer, "0", 35, DEFAULT_H_WINDOW_HEIGHT - 170, light_gray);
    render_text(h_window.renderer, "255", DEFAULT_H_WINDOW_WIDTH - 65, DEFAULT_H_WINDOW_HEIGHT - 170, light_gray);

    // Atualizar média / desvio (calcula com os pixels atuais)
    float avg_intensity = calculate_average_intensity();
    float std_deviation = calculate_standard_deviation();

    // Classificações em string (e também log)
    const char *class_intensity = classify_intensity_string((int)roundf(avg_intensity));
    const char *class_deviation = classify_deviation_string(std_deviation);

    // Exibir valores numéricos
    char str_avg_intensity[16];
    char str_std_deviation[16];
    snprintf(str_avg_intensity, sizeof(str_avg_intensity), "%.2f", avg_intensity);
    snprintf(str_std_deviation, sizeof(str_std_deviation), "%.2f", std_deviation);

    render_text(h_window.renderer, "Media:", 20, 100, light_gray);
    render_text(h_window.renderer, str_avg_intensity, 80, 100, light_gray);
    render_text(h_window.renderer, "Desvio Padrao:", 20, 120, light_gray);
    render_text(h_window.renderer, str_std_deviation, 140, 120, light_gray);

    // Exibir as classificacoes (texto)
    render_text(h_window.renderer, "Classificacao Intensidade:", 20, 150, light_gray);
    render_text(h_window.renderer, class_intensity, 220, 150, light_gray);

    render_text(h_window.renderer, "Classificacao Contraste:", 20, 170, light_gray);
    render_text(h_window.renderer, class_deviation, 220, 170, light_gray);

    SDL_SetWindowPosition(h_window.window, 10, SDL_WINDOWPOS_CENTERED);

    SDL_RenderPresent(h_window.renderer);
}

//------------------------------------------------------------------------------
// Loop principal
//------------------------------------------------------------------------------
static void loop(void)
{
    SDL_Log(">>> loop()");

    bool mustRefresh = false;
    render();

    SDL_Event event;
    bool isRunning = true;
    while (isRunning)
    {
        while (SDL_PollEvent(&event))
        {
            switch (event.type)
            {
            case SDL_EVENT_QUIT:
                isRunning = false;
                break;

            case SDL_EVENT_KEY_DOWN:
                if (event.key.key == SDLK_1 && !event.key.repeat)
                {
                    invert_image(g_window.renderer, &g_image);
                    calculate_histogram();
                    mustRefresh = true;
                }
                break;

            case SDL_EVENT_WINDOW_CLOSE_REQUESTED:
            {
                SDL_WindowID windowID = event.window.windowID;

                if (windowID == SDL_GetWindowID(g_window.window))
                {
                    SDL_Log("Pedido para fechar a janela principal. Encerrando o programa.");
                    isRunning = false;
                }
                else if (windowID == SDL_GetWindowID(h_window.window))
                {
                    SDL_Log("Pedido para fechar a janela secundária.");
                    SDL_HideWindow(h_window.window);
                }
            }
            break;
            }
        }

        if (mustRefresh)
        {
            render();
            mustRefresh = false;
        }
    }

    SDL_Log("<<< loop()");
}

//------------------------------------------------------------------------------
// Intensidade / média / desvio padrão / histograma
//------------------------------------------------------------------------------
float calculate_intensity(Uint8 r, Uint8 g, Uint8 b)
{
    return (r + g + b) / 3.0f;
}

float calculate_average_intensity()
{
    if (!g_image.surface) return 0.0f;

    int pixelCount = g_image.surface->w * g_image.surface->h;
    if (pixelCount == 0) return 0.0f;

    float soma = 0.0f;

    SDL_LockSurface(g_image.surface);
    Uint32 *pixels = (Uint32 *)g_image.surface->pixels;
    const SDL_PixelFormatDetails *format = SDL_GetPixelFormatDetails(g_image.surface->format);

    for (int i = 0; i < pixelCount; i++)
    {
        Uint8 r = 0, g = 0, b = 0, a = 0;
        SDL_GetRGBA(pixels[i], format, NULL, &r, &g, &b, &a);
        soma += calculate_intensity(r, g, b);
    }
    SDL_UnlockSurface(g_image.surface);

    return soma / (float)pixelCount;
}

float calculate_standard_deviation()
{
    if (!g_image.surface) return 0.0f;

    int pixelCount = g_image.surface->w * g_image.surface->h;
    if (pixelCount == 0) return 0.0f;

    float media = calculate_average_intensity();
    float soma = 0.0f;

    SDL_LockSurface(g_image.surface);
    Uint32 *pixels = (Uint32 *)g_image.surface->pixels;
    const SDL_PixelFormatDetails *format = SDL_GetPixelFormatDetails(g_image.surface->format);

    for (int i = 0; i < pixelCount; i++)
    {
        Uint8 r = 0, g = 0, b = 0, a = 0;
        SDL_GetRGBA(pixels[i], format, NULL, &r, &g, &b, &a);

        float intensidade = calculate_intensity(r, g, b);
        float diff = intensidade - media;
        soma += diff * diff;
    }
    SDL_UnlockSurface(g_image.surface);

    float variancia = soma / (float)pixelCount;
    return sqrtf(variancia);
}

void calculate_histogram()
{
    if (!g_image.surface) return;

    for (int i = 0; i < 256; ++i) histogram[i] = 0;

    int pixelCount = g_image.surface->w * g_image.surface->h;
    if (pixelCount == 0) return;

    SDL_LockSurface(g_image.surface);
    Uint32 *pixels = (Uint32 *)g_image.surface->pixels;
    const SDL_PixelFormatDetails *format = SDL_GetPixelFormatDetails(g_image.surface->format);

    for (int i = 0; i < pixelCount; i++)
    {
        Uint8 r = 0, g = 0, b = 0, a = 0;
        SDL_GetRGBA(pixels[i], format, NULL, &r, &g, &b, &a);
        int intensity = (int)roundf(calculate_intensity(r, g, b));
        if (intensity >= 0 && intensity <= 255)
            histogram[intensity]++;
    }

    SDL_UnlockSurface(g_image.surface);
}

//------------------------------------------------------------------------------
// Classificacao (retornam strings para exibir)
//------------------------------------------------------------------------------
const char *classify_intensity_string(int intensity)
{
    const char *res;
    if (intensity < 85)
        res = "Imagem escura";
    else if (intensity <= 170)
        res = "Intensidade media";
    else
        res = "Imagem clara";

    SDL_Log("Média (%.0f) -> %s", (float)intensity, res);
    return res;
}

const char *classify_deviation_string(float deviation)
{
    const char *res;
    if (deviation < 52.0f)
        res = "Baixo contraste";
    else if (deviation <= 104.0f)
        res = "Contraste medio";
    else
        res = "Alto contraste";

    SDL_Log("Desvio(%.2f) -> %s", deviation, res);
    return res;
}

//------------------------------------------------------------------------------
// main()
//------------------------------------------------------------------------------
int main(int argc, char *argv[])
{
    atexit(shutdown);

    if (argc < 2)
    {
        SDL_Log("Erro: O caminho para a imagem não foi fornecido.");
        SDL_Log("Uso: %s <arquivo_imagem>", argv[0]);
        return SDL_APP_FAILURE;
    }

    if (initialize() == SDL_APP_FAILURE)
        return SDL_APP_FAILURE;

    // Carrega a fonte
    g_font = TTF_OpenFont(FONT_FILENAME, FONT_SIZE);
    if (!g_font)
    {
        SDL_Log("Erro ao carregar a fonte '%s': %s", FONT_FILENAME, SDL_GetError());
        // prosseguir sem fonte não é útil, encerre
        return SDL_APP_FAILURE;
    }

    load_rgba32(argv[1], g_window.renderer, &g_image);

    calculate_histogram();

    int imageWidth = (int)g_image.rect.w;
    int imageHeight = (int)g_image.rect.h;

    if (imageWidth > DEFAULT_WINDOW_WIDTH || imageHeight > DEFAULT_WINDOW_HEIGHT)
    {
        SDL_Log("Redefinindo dimensoes da janela para (%d, %d).", imageWidth, imageHeight);
        SDL_SetWindowSize(g_window.window, imageWidth, imageHeight);
        SDL_SetWindowPosition(g_window.window, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED);

        // posicionar janela secundaria à direita
        int main_x = 0, main_y = 0, main_w = 0, main_h = 0;
        SDL_GetWindowPosition(g_window.window, &main_x, &main_y);
        SDL_GetWindowSize(g_window.window, &main_w, &main_h);

        int secondary_x = main_x + main_w + 10;
        int secondary_y = main_y;
        SDL_SetWindowPosition(h_window.window, secondary_x, secondary_y);
    }

    loop();

    return 0;
}
